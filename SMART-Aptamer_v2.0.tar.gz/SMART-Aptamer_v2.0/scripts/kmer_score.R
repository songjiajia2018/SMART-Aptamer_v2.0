#!/usr/bin/Rscript
args<-commandArgs(T)
a=as.numeric(args[1])
b=args[2]
file=paste(b,'/',"score_kmers.txt",sep='')
data=read.table(file)
kmer_scores=data$V2
pdf(file=paste(b,'/',"ecdf.pdf",sep=''))
par(mfrow=c(1,2))
fn=ecdf(kmer_scores)
plot(fn,verticals = TRUE, do.points =F)
kmer_scores=c(kmer_scores,rep(0,4^a-dim(data)[1]))
fn=ecdf(kmer_scores)
plot(fn,verticals = TRUE, do.points =F)
dev.off()
